// src/Chatbot.js
import React, { useState } from 'react';
import './Chatbot.css'; // Import your CSS file

const Chatbot = () => {
    const [messages, setMessages] = useState([{ text: "👋 Hi there! How can I help you today?", sender: "bot" }]);
    const [userInput, setUserInput] = useState('');

    const handleInputChange = (e) => {
        setUserInput(e.target.value);
    };

    const handleSendMessage = () => {
        if (userInput.trim()) {
            const newMessage = { text: userInput, sender: "user" };
            setMessages([...messages, newMessage]);
            setUserInput('');

            // Simulate a bot response
            setTimeout(() => {
                const botMessage = { text: "Thanks for your message!", sender: "bot" };
                setMessages(prevMessages => [...prevMessages, botMessage]);
            }, 1000);
        }
    };

    return (
        <div className="chat-container">
            <div className="chat-header">
                <h2>Chatbot</h2>
            </div>
            <div className="chat-box" id="chat-box">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.sender}-message`}>
                        {msg.text}
                    </div>
                ))}
            </div>
            <div className="input-area">
                <input
                    type="text"
                    id="user-input"
                    placeholder="Type your message..."
                    value={userInput}
                    onChange={handleInputChange}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <button id="send-btn" onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

export default Chatbot;
