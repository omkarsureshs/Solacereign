from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.contrib.auth.models import User
from .models import InteractionLog, MentalHealthTip
from .serializers import InteractionLogSerializer, MentalHealthTipSerializer

# List and create interaction logs
class InteractionLogView(generics.ListCreateAPIView):
    queryset = InteractionLog.objects.all()
    serializer_class = InteractionLogSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

# List mental health tips
class MentalHealthTipListView(generics.ListAPIView):
    queryset = MentalHealthTip.objects.all()
    serializer_class = MentalHealthTipSerializer

# Chatbot interaction endpoint
class ChatbotResponseView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user_message = request.data.get("message")
        # Sample bot response (can be integrated with NLP or AI models)
        bot_response = f"You said: {user_message}. Here is some encouragement: Keep going!"

        # Log the interaction
        InteractionLog.objects.create(
            user=request.user, message=user_message, response=bot_response
        )

        return Response({"response": bot_response}, status=status.HTTP_200_OK)

def home(request):
    return render(request, 'home.html')