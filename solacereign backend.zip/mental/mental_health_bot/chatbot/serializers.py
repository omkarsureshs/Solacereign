from rest_framework import serializers
from .models import InteractionLog, MentalHealthTip

class InteractionLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = InteractionLog
        fields = ['id', 'user', 'message', 'response', 'timestamp']

class MentalHealthTipSerializer(serializers.ModelSerializer):
    class Meta:
        model = MentalHealthTip
        fields = ['id', 'title', 'content', 'created_at']
