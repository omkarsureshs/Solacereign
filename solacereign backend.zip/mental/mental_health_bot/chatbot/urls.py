from xml.etree.ElementInclude import include
from django.urls import path
from .views import InteractionLogView, MentalHealthTipListView, ChatbotResponseView
from chatbot import views



urlpatterns = [
    path('logs/', InteractionLogView.as_view(), name="interaction-logs"),
    path('tips/', MentalHealthTipListView.as_view(), name="mental-health-tips"),
    path('chat/', ChatbotResponseView.as_view(), name="chatbot-response"),
    path('', views.home, name='home'),  # Homepage URL
]
